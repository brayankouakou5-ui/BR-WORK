# BR WORK — première base de construction

BR WORK est une application de productivité en français, avec identité noir / champagne doré.
Cette première version contient un tableau de bord, les tâches, un calendrier des échéances,
les rappels, les classeurs, les notes, un thème clair/sombre et l'export/import JSON.

## Données et fonctionnement
- Les données sont conservées localement dans le stockage du navigateur / WebView.
- Aucune création de compte ni aucun serveur n'est nécessaire pour cette première version.
- La base web est installable comme PWA sur un navigateur compatible.
- Le projet est préparé pour Capacitor et le plugin de notifications locales Android.
- Les notifications Android doivent être testées après compilation sur un vrai appareil.
- Cette version est une base de démarrage, pas encore une version APK signée prête à publier.

## Construire l'APK Android
La compilation Android nécessite un environnement de compilation Android (local ou cloud).
Depuis un environnement avec Node.js, Java et Android SDK :
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android`
5. Dans Android Studio : Build > Build Bundle(s) / APK(s) > Build APK(s)

Pour une compilation sans Android Studio sur le téléphone, le projet peut être envoyé dans
un dépôt GitHub et compilé avec un workflow GitHub Actions configuré avec Android SDK.
Le téléphone seul ne peut pas compiler/signature un APK natif sans service ou environnement
de build distant.

## Étapes suivantes recommandées
1. Finaliser les écrans et les interactions.
2. Ajouter gestion des pièces jointes dans les classeurs.
3. Ajouter récurrence des rappels et vérification des permissions Android.
4. Ajouter sauvegarde/restauration plus avancée et tests sur plusieurs tailles d'écran.
5. Configurer une compilation cloud et une signature APK/AAB.

## Identifiant Android
`com.brlamelodie.brwork`


## Compilation cloud préparée
Un workflow GitHub Actions est fourni dans `.github/workflows/android-apk.yml`.
Après avoir envoyé le contenu de ce dossier dans un dépôt GitHub :
- l'envoi sur la branche `main` déclenche une compilation ;
- ou lancer manuellement `Build BR WORK APK` depuis l'onglet Actions ;
- à la fin, ouvrir l'exécution réussie et télécharger l'artefact `BR-WORK-debug-APK`.

L'APK debug sert aux essais sur téléphone. Pour une publication sur Google Play,
il faudra ensuite générer une version release signée avec une clé privée conservée en sécurité.
